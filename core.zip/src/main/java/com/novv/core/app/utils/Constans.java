package com.novv.core.app.utils;

public class Constans {

    public static final String VoicerPreference ="voicer_preference";
    public static final String SpeedPreference ="speed_preference";
}
