package com.novv.core.mvp.event;

public class ChooseMan {
}
